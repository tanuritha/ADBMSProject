#ifndef _ix_test_util_h_
#define _ix_test_util_h_

#ifndef _fail_
#define _fail_
const int fail = -1;
#endif

#include "ix.h"
#include "../rbf/test_util.h"

#endif


