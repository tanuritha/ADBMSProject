make rbftest1
./rbftest1
make rbftest2
./rbftest2
make rbftest3
./rbftest3
make rbftest4
./rbftest4
make rbftest5
./rbftest5
make rbftest6
./rbftest6
make rbftest7
./rbftest7
make rbftest8
./rbftest8
make rbftest8b
./rbftest8b
make rbftest9
./rbftest9
make rbftest10
./rbftest10
make rbftest11
./rbftest11
make rbftest12
./rbftest12
make rbftest_p0
./rbftest_p0
make rbftest_p1
./rbftest_p1
make rbftest_p1b
./rbftest_p1b
make rbftest_p1c
./rbftest_p1c
make rbftest_p2
./rbftest_p2
make rbftest_p2b
./rbftest_p2b
make rbftest_p3
./rbftest_p3
make rbftest_p4
./rbftest_p4
make rbftest_p5
./rbftest_p5
make rbftest_delete
./rbftest_delete
make rbftest_update
./rbftest_update