make clean
make rmtest_create_tables
./rmtest_create_tables
make rmtest_00
./rmtest_00
make rmtest_01
./rmtest_01
make rmtest_02
./rmtest_02
make rmtest_03
./rmtest_03
make rmtest_04
./rmtest_04
make rmtest_05
./rmtest_05
make rmtest_06
./rmtest_06
make rmtest_07
./rmtest_07
make rmtest_08
./rmtest_08
make rmtest_09
./rmtest_09
make rmtest_10
./rmtest_10
make rmtest_11
./rmtest_11
make rmtest_12
./rmtest_12
make rmtest_13
./rmtest_13
make rmtest_13b
./rmtest_13b
make rmtest_14
./rmtest_14
make rmtest_15
./rmtest_15
